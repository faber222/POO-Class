package engtelecom.poo;

import java.util.Random;

public class Buzz {

    // atributos 
    private boolean asaAberta; 
    private boolean capaceteAberto;
    private String[] frases; // = {"Frase 1", "Frase 2"};


    public Buzz() {
        this.asaAberta = false;
        this.capaceteAberto = false;
        this.frases = new String[]{"Frase 1", "Frase 2"};
    }

    

    public boolean isAsaAberta() {
        return asaAberta;
    }

    public boolean isCapaceteAberto() {
        return capaceteAberto;
    }


    public void abrirCapacete(){
        this.capaceteAberto = true;
    }

    public void fecharCapacete(){
        this.capaceteAberto = false;
    }

    public boolean abrirFecharAsa(){
        this.asaAberta = !this.asaAberta;
        return this.asaAberta;
    }

    public String dispararLaser(){
        return "Disparando laser";
    }

    public String golpear(){
        return "Golpe";
    }

    public String falarFrase(){
        Random r = new Random();

        int n = r.nextInt(this.frases.length);

        return this.frases[n];
    } 
}
